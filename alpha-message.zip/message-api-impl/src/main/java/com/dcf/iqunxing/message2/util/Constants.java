package com.dcf.iqunxing.message2.util;

public interface Constants {

    public static final String MESSAGE_JOB_SERVICE_PASSWORD = "12dsas2x";
}
