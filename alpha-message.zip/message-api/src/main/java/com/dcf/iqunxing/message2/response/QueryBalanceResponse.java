package com.dcf.iqunxing.message2.response;

public class QueryBalanceResponse extends BaseResponse {

    private static final long serialVersionUID = 7343313946933884897L;

}
