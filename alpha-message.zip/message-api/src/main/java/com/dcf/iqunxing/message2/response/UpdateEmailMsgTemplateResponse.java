package com.dcf.iqunxing.message2.response;

public class UpdateEmailMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -7757533346191638819L;

}
