package com.dcf.iqunxing.message2.response;

public class DeletePushMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -7776288923374094999L;

}
