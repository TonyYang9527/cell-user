package com.dcf.iqunxing.message2.response;



public class UpdateSiteMsgResponse extends BaseResponse {

    private static final long serialVersionUID = -4945743569387470036L;

}
