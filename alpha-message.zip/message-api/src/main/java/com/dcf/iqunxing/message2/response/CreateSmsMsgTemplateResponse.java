package com.dcf.iqunxing.message2.response;

public class CreateSmsMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 4285990096519137442L;

    protected Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
