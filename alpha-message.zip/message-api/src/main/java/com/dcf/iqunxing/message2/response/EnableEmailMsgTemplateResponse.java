package com.dcf.iqunxing.message2.response;



public class EnableEmailMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -7813988683304840920L;

}
