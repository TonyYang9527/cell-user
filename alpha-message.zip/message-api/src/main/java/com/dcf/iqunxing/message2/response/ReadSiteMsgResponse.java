package com.dcf.iqunxing.message2.response;



public class ReadSiteMsgResponse extends BaseResponse {

    private static final long serialVersionUID = 6261708341152830100L;

}
