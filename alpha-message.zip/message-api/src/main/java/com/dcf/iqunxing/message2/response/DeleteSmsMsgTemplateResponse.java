package com.dcf.iqunxing.message2.response;

public class DeleteSmsMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 3732308772360126824L;

}
