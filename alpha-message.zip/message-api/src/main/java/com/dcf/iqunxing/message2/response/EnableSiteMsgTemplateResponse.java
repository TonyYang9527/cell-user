package com.dcf.iqunxing.message2.response;



public class EnableSiteMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -877295711011206825L;

}
