package com.dcf.iqunxing.message2.response;



public class CreateSiteMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 9132413204771365625L;

    protected Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
