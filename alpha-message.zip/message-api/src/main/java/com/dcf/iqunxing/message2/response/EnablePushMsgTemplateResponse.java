package com.dcf.iqunxing.message2.response;



public class EnablePushMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 6441166131580817577L;

}
