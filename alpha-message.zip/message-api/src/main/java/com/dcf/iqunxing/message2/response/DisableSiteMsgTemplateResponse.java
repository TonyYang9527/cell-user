package com.dcf.iqunxing.message2.response;



public class DisableSiteMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 1967489830377758468L;

}
