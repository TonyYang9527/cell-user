package com.dcf.iqunxing.message2.response;



public class DisablePushMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -7762779821980511815L;

}
