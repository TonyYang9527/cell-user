package com.dcf.iqunxing.message2.util;

public class Constant {

    /** 邮件收件人切割标识| */
    public static final String EMAIL_RECEIVER_SPILT = "|";

    /** 短信收件人切割标识, */
    public static final String SMS_RECEIVER_SPILT = ",";

    /** addition字段键值中key和value的分割标识|| key1=value1||key2=value2 */
    public static final String ADDITION_SPILT = "=";

    /** addition字段键值中key和value的分割标识|| key1=value1||key2=value2 */
    public static final String ADDITION_KV_SPILT = "||";

}
