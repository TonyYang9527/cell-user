package com.dcf.iqunxing.message2.response;



public class UpdateSiteMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 601692394686160744L;

}
