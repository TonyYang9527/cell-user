package com.dcf.iqunxing.message2.response;



public class DisableSmsMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -8128579152273712109L;

}
