package com.dcf.iqunxing.message2.response;

public class SendMessageResponse extends BaseResponse {

	private static final long serialVersionUID = 1757492396989145086L;

	protected Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
