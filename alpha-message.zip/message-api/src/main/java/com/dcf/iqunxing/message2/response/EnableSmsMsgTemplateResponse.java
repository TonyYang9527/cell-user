package com.dcf.iqunxing.message2.response;



public class EnableSmsMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 8534666328625242120L;

}
