package com.dcf.iqunxing.message2.response;



public class ProcessSiteMsgResponse extends BaseResponse {

    private static final long serialVersionUID = 3231340407883056595L;

}
