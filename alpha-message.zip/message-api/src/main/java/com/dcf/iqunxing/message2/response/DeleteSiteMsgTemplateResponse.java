package com.dcf.iqunxing.message2.response;



public class DeleteSiteMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = 1046235190970016060L;

}
