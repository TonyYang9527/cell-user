package com.dcf.iqunxing.message2.response;



public class DisableEmailMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -2334377450788135663L;

}
