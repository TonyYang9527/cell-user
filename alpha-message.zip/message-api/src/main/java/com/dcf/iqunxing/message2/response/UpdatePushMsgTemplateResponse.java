package com.dcf.iqunxing.message2.response;

public class UpdatePushMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -3872734558221961477L;

}
