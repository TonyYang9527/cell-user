package com.dcf.iqunxing.message2.request;


public class CreateSiteMsgRequest extends SiteMsgRequest {

    private static final long serialVersionUID = -5316135683210530146L;

}
