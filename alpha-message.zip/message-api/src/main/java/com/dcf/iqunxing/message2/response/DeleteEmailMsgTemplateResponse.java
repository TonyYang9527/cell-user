package com.dcf.iqunxing.message2.response;

public class DeleteEmailMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -1189582699345228816L;

}
