package com.dcf.iqunxing.message2.request;

import java.io.Serializable;

public class BaseRequest implements Serializable {

	private static final long serialVersionUID = -1130624887492091248L;

}
