package com.dcf.iqunxing.message2.response;

public class UpdateSmsMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -7750016905978070481L;

}
