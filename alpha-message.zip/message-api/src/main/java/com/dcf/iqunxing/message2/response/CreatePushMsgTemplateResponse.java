package com.dcf.iqunxing.message2.response;

public class CreatePushMsgTemplateResponse extends BaseResponse {

    private static final long serialVersionUID = -2004123566210225104L;

    protected Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
