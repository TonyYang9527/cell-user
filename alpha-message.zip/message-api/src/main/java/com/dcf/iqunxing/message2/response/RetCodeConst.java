package com.dcf.iqunxing.message2.response;

public class RetCodeConst {

    public static String SUCCESS = "0";

    public static String FAIL = "100";

}
