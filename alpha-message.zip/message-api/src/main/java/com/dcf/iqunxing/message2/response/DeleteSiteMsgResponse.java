package com.dcf.iqunxing.message2.response;



public class DeleteSiteMsgResponse extends BaseResponse {

    private static final long serialVersionUID = -5598519350140976311L;

}
