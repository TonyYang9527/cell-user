package com.dcf.iqunxing.message2.util;

public interface Constants {

    public static final String MESSAGE_JOB_SERVICE_PASSWORD = "12dsas2x";

    public static final long SMS_JOB_ID = 1L;

    public static final long SMS_CPST_JOB_ID = 2L;

    public static final long EMAIL_JOB_ID = 3L;

    public static final long EMAIL_CPST_JOB_ID = 4L;

    public static final long PUSH_JOB_ID = 5L;

    public static final long PUSH_CPST_JOB_ID = 6L;

    public static final long SITEMSG_JOB_ID = 7L;

    public static final long SITEMSG_CPST_JOB_ID = 8L;
}
